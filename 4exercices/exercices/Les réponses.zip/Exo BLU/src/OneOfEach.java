import java.util.ArrayList;

public class OneOfEach {
	
	/*fonction qui re�oit deux listes en param�tres
	 * renvoieune nouvelle liste dans laquelle les �l�ments proviennent tour � tour de la premi�re ou de la 2e liste re�ue.
	 */
	static ArrayList<Integer> Fonction(ArrayList<Integer> list1 ,ArrayList<Integer> list2 ){
        
        ArrayList<Integer> res = new ArrayList<Integer>(); // cr�ation de la liste res
     
	    int inc1 = 0; // iniatilisation de la valeur qui va nous permettre d'incr�menter les �l�ments tour � tour
	    int inc2 = 0;
	    
	    // On ajoute les �l�ments dans la liste tant qu'aucun incr�menteurs est plus grand que la liste 
	    while(inc1 < list1.size() && inc2 < list2.size() ){
	        
	        res.add(list1.get(inc1));
	        res.add(list2.get(inc2));
	        
	        inc1++;
	        inc2++;
	        
	        
	    }
	    
	    // On verifie si la liste n'as pas atteint son maximun sinon on continue � ajouter des �lements
	    if(inc1 < list1.size()){
	        
	        while(inc1 < list1.size()){
	            res.add(list1.get(inc1));
	            inc1++;
	        }
	        
	        
	    }
	    
	    if(inc2 < list2.size()){
	        
	        while(inc2 < list2.size()){
	            res.add(list2.get(inc2));
	            inc2++;
	        }
	    }
	        
	        
	        return res; // retourne la liste finale avec les �l�ment de lis1 et list2 tour � tour
	      
	        }
	        
	
	        
	
	     public static void main(String []args){
	        
	        ArrayList<Integer> test1 = new ArrayList<Integer>();
	        test1.add(1);
	        test1.add(-1);
	        test1.add(0);
	        test1.add(5);
	        test1.add(-8);
	        
	         ArrayList<Integer> test2 = new ArrayList<Integer>();
	        test2.add(7);
	        test2.add(7);
	        test2.add(7);
	        test2.add(7);
	        test2.add(7);
	        test2.add(7);
	      
	        
	        ArrayList<Integer> resultat =  Fonction(test1,test2);
	        
	        for(int y=0 ; y<resultat.size();y++){
	            
	           System.out.println(resultat.get(y));
	            
	        }
	    
	        
	     }

}
