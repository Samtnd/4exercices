public class TicTac {
	
	/*fonction qui affiche les nombres de 1 � 100 inclus, chacun sur une ligne. A cote de chaque nombre, ajout� une mention
	 * si le nombre est divisible par 3, �crire le nombre suivi de `Tic`
	 * si le nombre est divisible par 5, �crire le nombre suivi de `Tac`
	 * sinon, �crire simplement le nombre.
	 */
public static void main(String []args){
        
        for ( int i=1 ;i <=100; i++ ){ // Parcours des nombre de 1 � 100
            
            
           if(i%3 != 0 && i%5 != 0){ //Condition pour afficher tous les nombres qui ne repondent pas aux exigences des pr�cedente
               
               System.out.println(i);
           } 
            
            if(i%3 == 0 && i%5== 0){ // si le nombre est divisible par 3 et par 5 alors on affiche Tictac � c�t�
                
                System.out.println(String.valueOf(i) + " TicTac");
                
            }
            
            else {
            
            if(i%3 == 0){ // Si les nombre est divisible par 3 alors on affiche tic
                
                 System.out.println(String.valueOf(i)+ " Tic");
                
            }
            
            if(i%5 == 0){ // Si les nombre est divisible par 5 alors on affiche tac
                
                 System.out.println(String.valueOf(i)+" Tac");
                
            }
            
            
        }
        }
        
        
        
        
     }
}
