import java.util.ArrayList;

public class DoubleListe {
	
	/*fonction qui re�oit une `liste` en param�tre et affiche deux listes:
	 * la premi�re `liste` affich�e contiendra tous les nombres strictement n�gatifs contenus dans la liste re�ue
	 * la seconde `liste` affich�e contiendra tous les nombres positifs contenus dans la liste re�ue
	 */
	
	
static void Fonction(ArrayList<Integer> s ){
        
        ArrayList<Integer> neg = new ArrayList<Integer>(); // On sp�cifie quel type d'objet que contiendra ma liste neg (Integer)
        ArrayList<Integer> pos = new ArrayList<Integer>(); // On sp�cifie quel type d'objet que contiendra ma liste pos (Integer)
        

        for(int i=0 ; i<s.size();i++){ // Parcours de l'�lement pass� en param�tre
            
            if(s.get(i) >= 0 ){ // On v�rifie ici si le nombre est positif
            
            pos.add(s.get(i)); // On ajoute une par une des �l�ment entier positif dans la liste 
            
            }
            
            else {
                neg.add(s.get(i)); // On ajoute une par une des �l�ment n�gatif positif dans la liste 
            }
            
        }
        
         System.out.println("Liste nombre positifs :");
        
          for(int x=0 ; x<pos.size();x++){ 
            
           System.out.println(pos.get(x)); // affichage des nombre positifs
            
        }
        
        System.out.println("Liste nombre negatifs :");
        
          for(int y=0 ; y<neg.size();y++){
            
           System.out.println(neg.get(y)); //affichage des nombres n�gatifs
            
        }
        

        
    }

	// test
     public static void main(String []args){
        
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(1);
        test.add(-1);
        test.add(0);
        test.add(5);
        test.add(-8);
        
        Fonction(test);
    
        
     }

}
