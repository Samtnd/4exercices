import java.util.ArrayList;

public class Heads {
	
	/*fonction qui re�oit une cha�ne de caract�res en param�tre
	 * renvoie une liste de tous les pr�fixes possibles de la cha�ne.
	 */
	
	static ArrayList Fonction(String s ){
        
        ArrayList res = new ArrayList(); // cr�ation et initialisation de la liste
        
        res.add(" "); // ajout des espaces dans la liste
        
        for(int i=0 ; i<=s.length();i++){ // parcours de la liste pass� en param�tre
            
            res.add(s.substring(0,i)); // ajout de la nouvelle chaine qui est la sous-cha�ne de s pass� en param�tre
            
        }
        
        return res; //retourne la nouvelle liste de tous les pr�fixe de la cha�ne	
        
    }

	//test
     public static void main(String []args){
        
        
        ArrayList test = Fonction("abcdefg"); // On test la focntion ici avec le string pass� en param�tre
        
     for(int i=0 ; i<test.size();i++){
            
           System.out.println(test.get(i));
            
        } 
    
    
        
     }

}
